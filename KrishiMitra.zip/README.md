# KrishiMitra - Next.js & React Agricultural Intelligence Platform

**KrishiMitra Enterprise** is a production-ready, fully responsive Next.js 14 and React web application built with modern HTML, Vanilla CSS, Tailwind CSS, Lucide Icons, and client-side reactive state management with localStorage persistence and Supabase cloud backend integration.

It connects Indian farmers, agribusinesses, APMC traders, and grain millers with real-time market data, AI agronomic advisory, satellite weather radar, precision soil health testing, and government direct benefit transfers.

---

## 🚀 Quick Start (How to Run)

### Prerequisites
- **Node.js**: v20+ or v24 LTS (Installed and verified)
- **npm**: v10+ or v11+

### Installation & Launch
```bash
# Navigate to the project directory
cd d:\AgriSmart

# Install dependencies (already completed)
npm install

# Run the Next.js development server
npm run dev

# Or build and launch the optimized production bundle:
npm run build
npm start
```

Then open your browser at: **`http://localhost:3000`**

---

## 📱 Full Mobile & Desktop Responsiveness

The app is built from the ground up to fit seamlessly on **any screen size**:
- **Mobile Phones (320px - 640px)**:
  - Sticky top header with brand identity, notifications, and profile capsule
  - Slide-out mobile drawer menu with quick links and regional agro-climatic summary
  - Thumb-friendly bottom navigation bar (`Home`, `Mandi`, `B2B Hub`, `Weather`, `Profile`)
  - Full-width touch cards, 2-column metric cards, and horizontal touch sliders
  - Safe viewport margins and automatic overflow prevention (`overflow-x: hidden`)
- **Tablets & Laptops (641px - 1024px)**:
  - Adaptive 2-column and 3-column grids
  - Compact sidebar navigation and rich header widgets
- **Desktop & Widescreen (1025px+)**:
  - Persistent left sidebar with organized sections: *Core Operations*, *Agronomic AI & Climate*, *Direct Services*, *System & Account*
  - High-density data tables, live APMC arrival volume comparison, and interactive modals

---

## 🏛️ Application Routes & Production Screens

| Screen / Feature | Route | Key Capabilities |
| :--- | :--- | :--- |
| **Dashboard** | [`/`](http://localhost:3000) | Live weather ticker, storm hail alerts, auto-sliding banner carousel, 4 core metric cards, 6 quick intelligence modules, APMC live feed |
| **APMC Mandi Rates** | [`/mandi`](http://localhost:3000/mandi) | Live prices across 5 regional APMC yards (Khanna, Ludhiana, Jagraon, Samrala, Sahnewal), statutory MSP comparisons, arrival volumes |
| **B2B Trade Desk** | [`/b2b-hub`](http://localhost:3000/b2b-hub) | Dual-mode trade desk (`SELL` for farmers posting harvest lots, `BUY` for millers posting tenders), filter by 10 crops, direct call dialer |
| **Smart Crop AI** | [`/crop-ai`](http://localhost:3000/crop-ai) | AI agronomic engine ranking top 3 crops based on N-P-K & pH calibration, calculating suitability %, profit/acre, and market risk tags |
| **Soil Health Card** | [`/soil-health`](http://localhost:3000/soil-health) | 12-parameter certified soil certificate, nutrient gauges, organic carbon, and scientific fertilizer dosing recommendations (Urea, DAP, MOP) |
| **Weather & Radar** | [`/weather`](http://localhost:3000/weather) | Severe storm alerts, 24-hr hourly temperature slider, and 14-day cumulative precipitation probability chart |
| **Govt Schemes & DBT** | [`/schemes`](http://localhost:3000/schemes) | Directory of central and state welfare initiatives (PM-KISAN DBT ₹6,000, PMFBY crop insurance, 50% Kisan drone grants under SMAM, KCC 4%) |
| **Buyer Messages** | [`/messages`](http://localhost:3000/messages) | Direct buyer purchase bids with unread badges, counterparty profiles, and instant dialer modal |
| **Farmer Profile** | [`/profile`](http://localhost:3000/profile) | Identity verification, Punjab Mandi Board registration number (`PB-LDH-APMC-94821`), cultivated landholding, Aadhaar e-KYC |
| **GPS / Agro Zone** | [`/location`](http://localhost:3000/location) | Auto-detect satellite GPS or switch between agricultural zones (Indo-Gangetic Alluvial, Black Cotton / Regur, Malwa Plateau) |
| **Authentication** | [`/login`](http://localhost:3000/login) | Mobile phone OTP verification flow and Google Single Sign-On |

---

## 🛠️ Architecture & Tech Stack

- **Framework**: Next.js 14 (App Router)
- **Frontend**: React 18
- **Styling**: Tailwind CSS + Custom CSS (`Plus Jakarta Sans` & `JetBrains Mono` fonts, glassmorphism, glowing micro-animations)
- **Icons**: Lucide React
- **State Management**: React Context (`AgriContext`) with automatic `localStorage` synchronization
- **PWA & Production Ready**: Web app manifest, theme colors, responsive meta viewport, and zero mock/reviewer control panels
